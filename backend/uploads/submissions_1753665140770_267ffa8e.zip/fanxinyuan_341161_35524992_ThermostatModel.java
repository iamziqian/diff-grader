public class ThermostatModel {
  private double currentTemp = 22.0;
  private double targetTemp = 22.0;
  private boolean heatingOn = false;
  private boolean coolingOn = false;

  public void setTargetTemp(double temp) {
    targetTemp = temp;
  }

  public void updateSystem() {
    // Check if current temperature is less than target temperature
    if (currentTemp < targetTemp) {
      currentTemp += 0.1;
      if (currentTemp > targetTemp) {
        currentTemp = targetTemp;
      }
      heatingOn = true;
      coolingOn = false;
    }
    // Check if current temperature is more than target temperature
    else if (currentTemp > targetTemp) {
      currentTemp -= 0.1;
      if (currentTemp < targetTemp) {
        currentTemp = targetTemp;
      }
      heatingOn = false;
      coolingOn = true;
    } else {
      coolingOn = false;
      heatingOn = false;
    }
  }

  public double getCurrentTemp() {
    return currentTemp;
  }

  public double getTargetTemp() {
    return targetTemp;
  }

  public boolean isHeatingOn() {
    return heatingOn;
  }

  public boolean isCoolingOn() {
    return coolingOn;
  }
}
