import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ThermostatController implements ActionListener {

  //TO Do
  // Create required instance variables, make them private and final
  private final ThermostatModel model;
  private final ThermostatView view;


  public ThermostatController(ThermostatModel model, ThermostatView view) {
    //TO Do
    // Instantiate instance variables
    this.model = model;
    this.view = view;
  }

  public void run() {

    //TO DO
    // add current controller as a listener to view setTempButton (the method is already in view)
    this.view.addListener(this);

    // Timer to mimic real thermostat changing temperature behaviour
    Timer timer = new Timer(1000, new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        model.updateSystem();
        view.updateDisplay(
            //TO DO
            // Get current temprature from model
            model.getCurrentTemp(),
            // Get target temprature from model
            model.getTargetTemp(),
            // Get isHeatingOn from model
            model.isHeatingOn(),
            // Get isCoolingOn from model
            model.isCoolingOn()
        );
      }
    });
    timer.start();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    try {
      //TO DO
      //1- Get Input Temperature from the user and call it "input"
      String input = this.view.getTempInput();
      //2- Call method to set the target temperature
      this.model.setTargetTemp(Double.parseDouble(input));
      //3- Call show message in view to show: "Target set to " + input + "°C"
      this.view.showMessage("Target set to " + input + "°C");
      // call clearInput() in view
      this.view.clearInput();
    } catch (NumberFormatException ex) {
      this.view.showMessage("Invalid input!");
    }

  }
}
