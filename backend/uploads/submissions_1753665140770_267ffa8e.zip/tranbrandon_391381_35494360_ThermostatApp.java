public class ThermostatApp {

  public static void main(String[] args) {

    //TO DO
    // Create controller and run it to start the app
    ThermostatController myApp = new ThermostatController(new ThermostatModel(),
        new ThermostatView());
    myApp.run();
  }

}
