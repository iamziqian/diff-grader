public class ThermostatApp {

  public static void main(String[] args) {

    //TO DO
    // Create controller and run it to start the app
    ThermostatModel newModel = new ThermostatModel();
    ThermostatView newView = new ThermostatView();
    ThermostatController newController = new ThermostatController(newModel, newView);
    newController.run();

  }

}
