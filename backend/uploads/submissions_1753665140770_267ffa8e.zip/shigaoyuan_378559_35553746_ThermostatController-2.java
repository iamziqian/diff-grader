import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class ThermostatController implements ActionListener{
  private final ThermostatView view;
  private final ThermostatModel model;


  //TO Do
  // Create required instance variables, make them private and final


  public ThermostatController(ThermostatModel model, ThermostatView view) {
    this.model = model;
    this.view = view;
    //TO Do
    // Instantiate instance variables
  }

  public void run() {
    view.addSetTempListener(this);

    //TO DO
    // add current controller as a listener to view setTempButton (the method is already in view)

    // Timer to mimic real thermostat changing temperature behaviour
    Timer timer = new Timer(1000, new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        model.updateSystem();
        view.updateDisplay(
            model.getCurrentTemp(),
            model.getTargetTemp(),
            model.isHeatingOn(),
            model.isCoolingOn()
        );
      }
    });
    timer.start();
  }


  @Override
  public void actionPerformed(ActionEvent e) {
    try {
      //TO DO
      String inputText = view.getTempInput();
      int input = Integer.parseInt(inputText);

      model.setTargetTemp(input);

      view.showMessage("Target set to " + input + "°C");

      view.clearInput();

      view.updateDisplay(
          model.getCurrentTemp(),
          model.getTargetTemp(),
          model.isHeatingOn(),
          model.isCoolingOn()
      );

      //1- Get Input Temperature from the user and call it "input"
      //2- Call method to set the target temperature
      //3- Call show message in view to show: "Target set to " + input + "°C"
      // call clearInput() in view
    } catch (NumberFormatException ex) {
      view.showMessage("Invalid input!");
    }

  }
}
