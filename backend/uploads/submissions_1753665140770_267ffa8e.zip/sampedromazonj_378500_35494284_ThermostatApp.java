public class ThermostatApp {
  public static void main(String[] args) {
//TO DO
// Create controller and run it to start the app
    ThermostatModel model = new ThermostatModel();
    ThermostatView view = new ThermostatView();
    ThermostatController controller = new ThermostatController(model, view);

    controller.run();
  }
}