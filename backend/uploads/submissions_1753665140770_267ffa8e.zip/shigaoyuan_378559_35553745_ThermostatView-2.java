import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;

public class ThermostatView extends JFrame {

  private final JTextField tempInput = new JTextField(5);
  private final JButton setTempButton = new JButton("Set Temperature");
  private final JLabel currentLabel = new JLabel("Current Temp: ");
  private final JLabel targetLabel = new JLabel("Target Temp: ");
  private final JLabel statusLabel = new JLabel("Status: ");
  private final JLabel messageLabel = new JLabel();

  // Constructor to set up the GUI
  public ThermostatView() {
    setTitle("Thermostat");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new GridLayout(6, 1));
    setSize(300, 200);

    // Add temperature labels
    add(currentLabel);
    add(targetLabel);
    add(statusLabel);

    // Create input panel with text field and button
    JPanel inputPanel = new JPanel();
    inputPanel.add(new JLabel("Set Temp: "));
    inputPanel.add(tempInput);
    inputPanel.add(setTempButton);
    add(inputPanel);

    // Add message label
    add(messageLabel);

    setVisible(true);
  }

  // Register an ActionListener for the set temperature button
  public void addSetTempListener(ActionListener listener) {
    setTempButton.addActionListener(listener);
  }

  // Get the text entered in the input field
  public String getTempInput() {
    return tempInput.getText();
  }

  // Optional alias for compatibility with controller
  public String getUserInput() {
    return getTempInput();
  }

  // Clear the input field
  public void clearInput() {
    tempInput.setText("");
  }

  // Display a message on the screen
  public void showMessage(String msg) {
    messageLabel.setText(msg);
  }

  // Update the temperature and system status display
  public void updateDisplay(double current, double target, boolean heating, boolean cooling) {
    currentLabel.setText("Current Temp: " + String.format("%.1f", current));
    targetLabel.setText("Target Temp: " + String.format("%.1f", target));
    statusLabel.setText("Status: " + (heating ? "Heating" : cooling ? "Cooling" : "Idle"));
  }
}
