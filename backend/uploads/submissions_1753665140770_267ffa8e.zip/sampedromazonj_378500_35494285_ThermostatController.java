import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ThermostatController implements ActionListener {
  //TO Do
// Create required instance variables, make them private and final

  private final ThermostatModel model;
  private final ThermostatView view;


  public ThermostatController(ThermostatModel model, ThermostatView view) {
//TO Do
// Instantiate instance variables
    this.model = model;
    this.view = view;
  }

  public void run() {
//TO DO
// add current controller as a listener to view setTempButton (the method is already in view)
    view.addListener(this);
// Timer to mimic real thermostat changing temperature behaviour
    Timer timer = new Timer(1000, new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        model.updateSystem();
        view.updateDisplay(model.getCurrentTemp(), model.getTargetTemp(), model.isHeatingOn(),
            model.isCoolingOn());
      }
    });
    timer.start();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    try {
//TO DO
//1- Get Input Temperature from the user and call it "input"
      double input = Double.parseDouble(view.getTempInput());
//2- Call method to set the target temperature
      model.setTargetTemp(input);
//3- Call show message in view to show: "Target set to " + input + "°C"
      String msg = "Target set to " + input + "°C";
      view.showMessage(msg);
// call clearInput() in view
      view.clearInput();
    } catch (NumberFormatException ex) {
      view.showMessage("Invalid input!");
    }
  }
}