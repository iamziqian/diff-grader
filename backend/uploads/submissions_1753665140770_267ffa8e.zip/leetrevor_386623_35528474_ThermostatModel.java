public class ThermostatModel {

  private double currentTemp = 22.0;
  private double targetTemp = 22.0;
  private boolean heatingOn = false;
  private boolean coolingOn = false;

  public void setTargetTemp(double temp) {
    targetTemp = temp;
  }

  public void updateSystem() {

    //TO DO

    // Check if current temperature is less than target temperature
    // then increase current temperature by 0.1 degrees and update (heatingOn coolingOn currentTemp)
    if (currentTemp < targetTemp) {
      currentTemp += 0.1;
      heatingOn = true;
      coolingOn = false;

    }
    // Check if current temperature is more than target temperature
    // then decrease current temperature by 0.1 degrees and update (heatingOn coolingOn currentTemp)
    else if (currentTemp > targetTemp) {
      currentTemp -= 0.1;
      heatingOn = false;
      coolingOn = true;
    } else {
      coolingOn = false;
      heatingOn = false;
    }
  }

  public double getCurrentTemp() {
    return currentTemp;
  }

  public double getTargetTemp() {
    return targetTemp;
  }

  public boolean isHeatingOn() {
    return heatingOn;
  }

  public boolean isCoolingOn() {
    return coolingOn;
  }
}
