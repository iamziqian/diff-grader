public class ThermostatModel {
  private double currentTemp = 22.0;
  private double targetTemp = 22.0;
  private boolean heatingOn = false;
  private boolean coolingOn = false;

  public void setTargetTemp(double temp) {
    targetTemp = temp;
  }

  public void updateSystem() {

    //TO DO

    // Check if current temperature is less than target temperature
    // then increase current temperature by 0.1 degrees and update (heatingOn coolingOn currentTemp)
    // by adding the + 0.05 and -0.05 to the current temp we can remove the floating point error
    // the if statements now check if current temp is more than 0.05 degrees below target temp
    // and if current temp is more than 0.05 degrees above the target temp
    if (currentTemp + 0.05 < targetTemp) {
      currentTemp += 0.1;
      coolingOn = false;
      heatingOn = true;
    }
    // Check if current temperature is more than target temperature
    // then decrease current temperature by 0.1 degrees and update (heatingOn coolingOn currentTemp)
    else if (currentTemp - 0.05 > targetTemp) {
      currentTemp -= 0.1;
      coolingOn = true;
      heatingOn = false;

    } else {
      coolingOn = false;
      heatingOn = false;
    }
  }

  public double getCurrentTemp() {
    return currentTemp;
  }

  public double getTargetTemp() {
    return targetTemp;
  }

  public boolean isHeatingOn() {
    return heatingOn;
  }

  public boolean isCoolingOn() {
    return coolingOn;
  }
}
