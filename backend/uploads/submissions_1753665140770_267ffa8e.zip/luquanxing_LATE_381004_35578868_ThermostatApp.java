public class ThermostatApp {

  public static void main(String[] args) {

    //TO DO
    // Create controller and run it to start the app
    ThermostatView view = new ThermostatView();
    ThermostatModel model = new ThermostatModel();
    ThermostatController controller = new ThermostatController(model, view);
    controller.run();

  }

}
